import os

print(os.listdir(databases))